clear;
disp('~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~')
disp('Energy Efficient (SE)Motor parameters')
disp('~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~')

f=50; %Supply frequency [Hz]
p=4; %Number of poles
V1=380/sqrt(3); %Supply voltage [phase]
R1=2.087; %Stator winding resistance [ohms/phase]
X1=4.274; %Stator winding leakage reactance [ohms/phase]
Xm=66.560; %Stator winding magnetising reactance [ohms/phase]
X2p=4.274; %Rotor winding leakage reactance reffered to stator [ohms/phase]
R2p=2.122; %Rotor winding resistance reffered to stator [ohms/phase]

fprintf('f=%f\n',f);
fprintf('p=%f\n',p);
fprintf('V1=%f\n',V1);
fprintf('R1=%f\n',R1);
fprintf('X1=%f\n',X1);
fprintf('Xm=%f\n',Xm);
fprintf('X2p=%f\n',X2p);
fprintf('R2p=%f\n',R2p);

disp('~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~')
disp('Question 1:Thevenin Equiv Cct Parameters for SE Motor:')
disp('~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~')

Vth=Xm/sqrt(R1^2+(X1+Xm)^2)*V1; %Thevenin equiv voltage source [V] (Equ 5.45 -Sen)
Zth=1i*Xm*(R1+1i*X1)/(R1+1i*(X1+Xm)); %Thevenin equiv impedance
Rth=real(Zth); %Thevenin equiv resistance [ohms]
Xth=imag(Zth); %Thevenin equiv reactance [ohms]

fprintf('Vth=%f\n',Vth);
fprintf('Rth=%f\n',Rth);
fprintf('Xth=%f\n',Xth);

disp('~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~')
disp('QUESTION 2:Torque versus speed characteristics for SE Motor:')
disp('~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~')

ns=120*f/p; %Synchronous speed [rpm]
ws=2*pi*ns/60; %Synchronous speed [rad/sec]
s=0.0005:0.0005:1; %Slip [pu]
n=(1-s)*ns; %Rotor speed [rpm]
w=2*pi*n/60; %Rotor speed [rad/sec]

Tmech=3/ws*Vth^2./((Rth+R2p./s).^2+(Xth+X2p)^2).*R2p./s; %Total Tmech = {3*(Equ5.54- Sen)}
%Plot the Torque vs speed characteristics of motor:
figure(1)
subplot(2,2,1),
plot(n,Tmech,'b'),xlabel('n [rpm]'),ylabel('Torque [Nm]'),...
title('Torque vs speed'),grid on,...
hold on

Tstart=3/ws*Vth^2./((Rth+R2p).^2+(Xth+X2p)^2).*R2p;
fprintf('Tstart=%f\n',Tstart);

Tmax=3/(2*ws)*Vth^2./(Rth+sqrt(Rth^2+(Xth+X2p)^2));
fprintf('Tmax=%f\n',Tmax);

sTmax=R2p/(sqrt(Rth^2+(Xth+X2p)^2));
nTmax=(1-sTmax)*ns;
fprintf('STmax=%f\n',sTmax);
fprintf('nTmax=%f\n',nTmax);

disp('~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~')
disp('QUESTION 3:Stator current versus speed characteristics for SE Motor:')
disp('~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~')

Z1start=(R1+1i*X1)+((1i*Xm*(R2p+1i*X2p))/(R2p+1i*(Xm+X2p)));
I1start=V1/Z1start;
fid = 1;
fprintf(fid,'Z1start=%f%+fj\n',abs(Z1start),rad2deg(angle(Z1start)));
fprintf(fid,'I1start=%f%+fj\n',abs(I1start),rad2deg(angle(I1start)));

Z1Tmax=(R1+1i*X1)+((1i*Xm*((R2p/sTmax)+1i*X2p))/((R2p/sTmax)+1i*(Xm+X2p)));
I1Tmax=V1/Z1Tmax;

fprintf(fid,'Z1Tmax=%f%+fj\n',abs(Z1Tmax),rad2deg(angle(Z1Tmax)));
fprintf(fid,'I1Tmax=%f%+fj\n',abs(I1Tmax),rad2deg(angle(I1Tmax)));

Z1=R1+1i*X1+(1i*Xm*((R2p./s)+1i*X2p))./((R2p./s)+1i*(Xm+X2p));
I1=V1./Z1;
%plot stator current vs speed
figure(2)
subplot(2,2,1),
plot(n,abs(I1),'b'),xlabel('n [rpm]'),ylabel('Stator Current [A]'),...
title('Stator Current vs speed'),grid on,...
hold on
Znl = R1 + 1i*(X1+Xm);
I1nl = V1/Znl;

fprintf(fid,'Znoload=%f%+fj\n',abs(Znl),rad2deg(angle(Znl)));
fprintf(fid,'I1noload=%f%+fj\n',abs(I1nl),rad2deg(angle(I1nl)));


disp('~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~')
disp('QUESTION 4:Power factor versus speed characteristics for SE Motor:')
disp('~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~')
figure(3)
Pf = cos(angle(I1));
%plot power factor vs speed
subplot(2,2,1),
plot(n,Pf,'b'),xlabel('n [rpm]'),ylabel('Power factor'),...
title('Power factor vs speed'),grid on,...
hold on

Pfstart = cosd(rad2deg(angle(I1start)));
fprintf('Pfstart=%f\n',Pfstart);

PfTmax = cosd(rad2deg(angle(I1Tmax)));
fprintf('PfTmax=%f\n',PfTmax);

Pfnl = cos(angle(I1nl));
fprintf('Pfnoload=%f\n',Pfnl);


disp('~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~')
disp('QUESTION 5:Input Power, Stator Copper Loss, Air Gap Power and Shaft Power versus speed characteristics for SE Motor:')
disp('~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~')

Pin = 3*V1.*abs(I1).*Pf;
P1cu = 3*abs(I1).^2*R1;
I2 = Vth./sqrt((Rth + (R2p./s)).^2 +(Xth + X2p)^2);
%I2 = Vth./((Rth + (R2p./s)) +1i*(Xth + X2p));
P2cu = 3*real(I2).^2*R2p;
Pag = Pin- P1cu;
%Pag = P2cu./s;
%Pshaft = Pag.*(1-s);
Pshaft = Pin-P1cu-P2cu;
%The powers vs speed
figure(6)
subplot(2,2,1),
plot(n,Pin,'r'),xlabel('n [rpm]'),ylabel('Powers'),...
title('Powers vs speed'),grid on,...
hold on
plot(n,P1cu,'b')
plot(n,P2cu,'c')
plot(n,Pag,'g')
plot(n,Pshaft,'k')
hold off
legend('Pin','P1cu','P2cu','Pag','Pshaft')

I2start = Vth/((Rth + R2p) +1i*(Xth + X2p));
P2custart = 3*abs(I2start).^2*R2p;
P1custart = 3*abs(I1start).^2*R1;
fprintf('P1custart=%f\n',P1custart);
fprintf('P2custart=%f\n',P2custart);

disp('~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~')
disp('QUESTION 6:Efficiency versus speed characteristics for SE Motor:')
disp('~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~')

I2Tmax = Vth/((Rth + (R2p/sTmax)) +1i*(Xth + X2p));%Rotor current@max torque
PinTmax = 3*V1.*abs(I1).*Pf;%Power in at max torque
P1cuTmax = 3*abs(I1Tmax)^2*R1;%Stator Copper loss
P2cuTmax = 3*abs(I2Tmax)^2*R2p;%Rotor copper loss at max torque
PagTmax = PinTmax- P1cuTmax;%Air gap Power at max torque
PshaftTmax = PinTmax-P1cuTmax-P2cuTmax;%Shaft Power at max torque

NTmax = PshaftTmax/PinTmax;%Efficiency at max torque
fprintf('NTmax=%f\n',NTmax);
%fprintf('Pout=%f\n',Pout);
N = Pshaft./Pin;%plot efficiency vs speed
%plot efficiency vs speed
figure(5)
subplot(2,2,1),
plot(n,N,'b'),xlabel('n [rpm]'),ylabel('Actual Efficiency'),...
title('Efficiency vs speed'),grid on,...
hold on

disp('~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~')
disp('QUESTION 7:Torque Load versus speed characteristics for SE Motor:')
disp('~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~')
%load torque characteristic vs nominal torque-speed characteristic
figure(7)
plot(n,Tmech,'b')






