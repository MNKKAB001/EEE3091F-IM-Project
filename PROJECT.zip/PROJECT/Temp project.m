clear;
disp('~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~')
disp('Energy Efficient (SE)Motor parameters')
disp('~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~')
f=50; %Supply frequency [Hz]
p=4; %Number of poles
V1=380/sqrt(3); %Supply voltage [phase]
R1=2.087; %Stator winding resistance [ohms/phase]
X1=4.274; %Stator winding leakage reactance [ohms/phase]
Xm=66.560; %Stator winding magnetising reactance [ohms/phase]
X2p=4.274; %Rotor winding leakage reactance reffered to stator [ohms/phase]
R2p=2.122; %Rotor winding resistance reffered to stator [ohms/phase]
fprintf('f=%f\n',f);
fprintf('p=%f\n',p);
fprintf('V1=%f\n',V1);
fprintf('R1=%f\n',R1);
fprintf('X1=%f\n',X1);
fprintf('Xm=%f\n',Xm);
fprintf('X2p=%f\n',X2p);
fprintf('R2p=%f\n',R2p);